<?php
/* Copyright (C) NAVER <http://www.navercorp.com> */

header('Location: ../index.php?module=admin');

/* End of file index.php */
/* Location: ./admin/index.php */
