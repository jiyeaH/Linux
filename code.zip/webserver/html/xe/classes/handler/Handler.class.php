<?php
/* Copyright (C) NAVER <http://www.navercorp.com> */

/**
 * An abstract class of (*)Handler 
 *
 * @author NAVER (developers@xpressengine.com)
 */
class Handler
{

}
/* End of file Handler.class.php */
/* Location: ./classes/handler/Handler.class.php */
